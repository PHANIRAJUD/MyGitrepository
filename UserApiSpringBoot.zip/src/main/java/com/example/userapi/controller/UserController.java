package com.example.userapi.controller;

import com.example.userapi.model.User;
import com.example.userapi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/process-users")
    public ResponseEntity<Map<String, List<User>>> processUsers(@RequestBody List<User> users) {
        Map<String, List<User>> result = userService.processUsers(users);
        return ResponseEntity.ok(result);
    }
}
