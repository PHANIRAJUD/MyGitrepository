package com.example.userapi.service;

import com.example.userapi.model.User;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class UserService {

    private static final String TARGET_API = "https://example.com/api/userinfo";

    public Map<String, List<User>> processUsers(List<User> users) {
        RestTemplate restTemplate = new RestTemplate();
        List<User> activeUsers = new ArrayList<>();
        List<User> inactiveUsers = new ArrayList<>();

        for (User user : users) {
            try {
                HttpHeaders headers = new HttpHeaders();
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.setBasicAuth("username", "password");

                Map<String, String> requestBody = new HashMap<>();
                requestBody.put("userId", user.getUserId());

                HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);
                ResponseEntity<String> response = restTemplate.postForEntity(TARGET_API, entity, String.class);

                if (response.getStatusCode().is2xxSuccessful()) {
                    activeUsers.add(user);
                } else {
                    inactiveUsers.add(user);
                }
            } catch (Exception e) {
                inactiveUsers.add(user);
            }
        }

        Map<String, List<User>> result = new HashMap<>();
        result.put("active", activeUsers);
        result.put("inactive", inactiveUsers);
        return result;
    }
}
